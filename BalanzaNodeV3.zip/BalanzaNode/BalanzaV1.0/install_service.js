const Service = require('node-windows').Service;

// Crea el servicio
const svc = new Service({
    name: 'Balanza_Service',
    description: 'Balanza ejecutándose como servicio.',
    script: 'C:\\BalanzaNode\\BalanzaV1.0\\server_balance.js', // Ruta absoluta a tu archivo Node.js
});

// Instala el servicio
svc.on('install', () => {
    console.log('Servicio instalado con éxito.');
    svc.start();
});

svc.install();
