const express = require('express');
const phpExpress = require('php-express')({
    binPath: 'php', // Ruta al ejecutable de PHP (asegúrate de que esté en tu PATH)
});

const app = express();
const PORT = 3000;

// Configurar PHP Express como motor de vistas
app.engine('php', phpExpress.engine);
app.set('views', __dirname + '/views');
app.set('view engine', 'php');

// Servir archivos PHP
app.all(/.+\.php$/, phpExpress.router);

// Servir archivos estáticos (CSS, JS, imágenes)
app.use(express.static('public'));

// Iniciar el servidor
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
