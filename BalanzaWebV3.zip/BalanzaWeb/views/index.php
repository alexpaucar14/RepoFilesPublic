<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Datos del Serialport</title>
    <script>
        async function obtenerDatos() {
            try {
                // Realizar solicitud a la misma página para obtener los datos
                const response = await fetch('mostrar_datos.php');
                const result = await response.json();

                // Mostrar los datos en la caja de texto
                document.getElementById('output').value = result.data || 'No hay datos disponibles';
            } catch (error) {
                console.error('Error al obtener los datos:', error);
                document.getElementById('output').value = 'Error al obtener los datos';
            }
        }
    </script>
</head>
<body>
    <h1>Datos del Serialport</h1>
    <button onclick="obtenerDatos()">Obtener Datos</button>
    <br><br>
    <textarea id="output" rows="5" cols="50" readonly></textarea>
</body>
</html>
