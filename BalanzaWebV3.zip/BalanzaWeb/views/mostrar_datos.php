<?php
session_start();

// Verificar si hay datos en la sesión
if (isset($_SESSION['serialData'])) {
    echo json_encode(['serialData' => $_SESSION['serialData']]);
} else {
    echo json_encode(['serialData' => 'No hay datos disponibles']);
}
