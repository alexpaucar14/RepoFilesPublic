<?php

// Configurar cabeceras para permitir solicitudes desde cualquier origen
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

session_start(); // Usar sesiones para almacenar temporalmente los datos

// Verificar si la solicitud es POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Capturar datos enviados desde Node.js
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    // Guardar datos en la sesión
    if ($data) {
        $_SESSION['serialData'] = $data;
        //echo json_encode(['status' => 'success', 'message' => 'Datos recibidos']);

        // Mostrar los datos recibidos
        echo json_encode([
            "success" => true,
            "message" => "Datos recibidos exitosamente.",
            "data" => $data
        ]);

    } else {
        echo json_encode(['status' => 'error', 'message' => 'No se recibieron datos válidos.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Método no permitido.']);
}
