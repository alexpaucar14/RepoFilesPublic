<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Datos del Serialport</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
        }
        .btn {
            margin-right: 10px;
        }
        textarea {
            font-family: monospace;
            font-size: 14px;
            resize: none;
        }
    </style>
    <script>
        // Función para obtener los datos JSON desde PHP
        async function getJsonData(balanza) {
            if (!balanza) {
                document.getElementById('output').textContent = 'Por favor, seleccione una balanza.';
                return;
            }
            try {
                const response = await fetch(`mostrar_datos.php?balanza=${encodeURIComponent(balanza)}`);
                if (response.ok) {
                    const data = await response.json();
                    document.getElementById('output').textContent =  JSON.stringify(data, null, 2) || 'Peso no disponible.';
                } else {
                    document.getElementById('output').textContent = 'Error al cargar los datos.';
                }
            } catch (error) {
                document.getElementById('output').textContent = 'Error al realizar la solicitud: ' + error.message;
            }
        }

        // Función para obtener solo los datos del peso
        async function getJsonDataPeso(balanza) {
            if (!balanza) {
                document.getElementById('output').textContent = 'Por favor, seleccione una balanza.';
                return;
            }
            try {
                const response = await fetch(`mostrar_datos.php?balanza=${encodeURIComponent(balanza)}`);
                if (response.ok) {
                    const data = await response.json();
                    document.getElementById('output').textContent = 
                        JSON.stringify(data?.data?.data?.data, null, 2) || 'Peso no disponible.';
                } else {
                    document.getElementById('output').textContent = 'Error al cargar los datos.';
                }
            } catch (error) {
                document.getElementById('output').textContent = 'Error al realizar la solicitud: ' + error.message;
            }
        }

    </script>
</head>
<body>
    <div class="container">
        <h1 class="text-center text-primary">Datos del Serialport</h1>
        <div class="text-center my-4">
            <select id="balanza" class="form-select mb-2" style="width: 200px; display: inline-block;">
                <option value="">Seleccione balanza</option>
                <option value="BAL_SEDE_01">Balanza 1</option>
                <option value="BAL_SEDE_02">Balanza 2</option>
                <option value="BAL_SEDE_03">Balanza 3</option>
            </select>
            <button class="btn btn-primary" onclick="getJsonData(document.getElementById('balanza').value)">Obtener Datos</button>
            <button class="btn btn-secondary" onclick="getJsonDataPeso(document.getElementById('balanza').value)">Obtener Solo Peso</button>
        </div>
        <div class="mb-3">
            <label for="output" class="form-label">Resultados:</label>
            <pre id="output" style="background-color: #e9ecef; padding: 10px; border-radius: 5px; font-family: monospace; font-size: 14px; overflow: auto;"></pre>
        </div>
    </div>

    <!-- Bootstrap JS (Opcional para interactividad adicional) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
