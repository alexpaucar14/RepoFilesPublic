<?php
header('Content-Type: application/json');

$balanza = isset($_GET['balanza']) ? $_GET['balanza'] : null;

if (!$balanza) {
    echo json_encode(["error" => "No se proporcionó el parámetro balanza."]);
    exit;
}

$file = "data_" . $balanza . ".json";

if (file_exists($file)) {
    echo file_get_contents($file);
} else {
    echo json_encode(["error" => "El archivo no existe para la balanza proporcionada."]);
}