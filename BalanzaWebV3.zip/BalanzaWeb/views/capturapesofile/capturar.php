<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    if (isset($data['balance'])) { // Verificar que el dato "balance" exista
        $dato_recibido = json_encode([
            "success" => true,
            "message" => "Datos recibidos exitosamente.",
            "data" => $data
        ]);

        $file = "data_" . $data['balance'] . ".json";
        file_put_contents($file, $dato_recibido); // Guardar en archivo

        echo $dato_recibido;
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Falta el dato balance en la solicitud.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Método no permitido.']);
}
