<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>API REST con jQuery</title>
    <!-- Incluir jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <h1>Consumo de API REST</h1>

    <label for="data-box">Dato recibido:</label>
    <input type="text" id="data-box" readonly>
    <br><br>
    <button id="fetch-button">Obtener dato</button>

    <script>
        // URL de la API REST
        const apiUrl = "https://5034-179-6-168-35.ngrok-free.app/serial-data";

        // Función para consumir la API y llenar la caja de texto
        function fetchData() {
            $.ajax({
                url: apiUrl,
                method: "GET",
                success: function (response) {
                    console.log(response);
                    // Llenar la caja de texto con el dato recibido
                    document.getElementById('data-box').value = response.data;
                },
                error: function (xhr, status, error) {
                    alert(`Error al obtener datos: ${status} - ${error}`);
                }
            });
        }

        // Asignar evento al botón
        document.getElementById('fetch-button').addEventListener('click', fetchData);
    </script>
</body>
</html>